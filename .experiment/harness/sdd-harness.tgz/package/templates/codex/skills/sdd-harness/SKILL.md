---
name: sdd-harness
description: Shared SDD/4D Harness runtime for Codex stage skills: reboot test, artifact reads/writes, gate receipts, stage advancement, and knowledge/evidence handoff.
license: MIT
compatibility: Codex, OpenSpec CLI, Trinity skills, planning-with-files
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-harness for Codex

Use this shared skill before any Codex `sdd-*` stage skill writes artifacts or claims completion.

## 4D Contract

4D is:

```text
DDD -> SDD -> BDD -> TDD
```

The existing 9-stage lifecycle stays intact. 4D adds explicit gates:

- DDD gate: domain boundary is clear before stable spec work.
- SDD gate: OpenSpec proposal/spec/design/tasks are explicit.
- BDD gate: behavior scenarios are concrete before TDD.
- TDD gate: tests trace back to scenarios and requirements.
- Evidence gate: verification, review, traceability, and archive writeback prove the chain.

## 5-Question Reboot Test

Before decisions, file edits, stage advancement, or completion, answer from disk:

1. Where am I? Read `.sdd/runs/<run>/workflow-frame.yaml`.
2. Where am I going? Read workflow frame and `openspec/changes/<change>/tasks.md`.
3. What is the goal? Read `openspec/changes/<change>/proposal.md`.
4. What have I learned? Read `openspec/changes/<change>/findings.md`.
5. What have I done? Read `openspec/changes/<change>/progress.md`.

If any answer is missing, stop and repair the missing artifact before continuing.

## Required 4D Artifacts

Use these templates when the stage requires them:

- `templates/sdd-harness/4d/domain-boundary.md`
- `templates/sdd-harness/4d/behavior-scenarios.md`
- `templates/sdd-harness/4d/traceability-matrix.md`

## Codex Gate Receipt

Every stage wrapper must end with a receipt in `progress.md`:

```markdown
## [YYYY-MM-DD HH:MM] <stage> - gate receipt
- DDD:
- SDD:
- BDD:
- TDD:
- Evidence:
- Verification:
```

Do not claim completion unless the receipt names the files and commands that prove the claim.
