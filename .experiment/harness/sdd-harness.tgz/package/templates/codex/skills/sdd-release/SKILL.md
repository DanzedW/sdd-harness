---
name: sdd-release
description: Codex wrapper for the SDD/4D release stage: document deploy mode, smoke evidence, rollback path, or no-deploy reason.
license: MIT
compatibility: Codex, sdd-harness
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-release

Use `sdd-harness` first.

## Purpose

Record deployment intent and operational evidence. Pure documentation or template changes may use release mode `skip`.

## Read

- verify evidence
- latest review verdict
- `tasks.md`
- `traceability-matrix.md`

## Write

- release note or no-deploy reason
- rollback path when deployment occurs
- `progress.md`

## Gate

- Release mode is `manual`, `automated`, or `skip`.
- Verify gate is rechecked against current evidence.
- Tasks are complete.
- Rollback path or no-deploy reason is explicit.

Append a Codex gate receipt to `progress.md`.
