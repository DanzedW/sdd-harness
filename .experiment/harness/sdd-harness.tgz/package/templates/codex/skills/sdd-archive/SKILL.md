---
name: sdd-archive
description: Codex wrapper for the SDD/4D archive stage: archive OpenSpec changes and write durable LLMWiki knowledge with traceability.
license: MIT
compatibility: Codex, sdd-harness, trinity-archive
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-archive

Use `sdd-harness` first, then `trinity-archive`.

## Purpose

Close the loop: promote accepted specs, preserve evidence, and write reusable knowledge.

## Read

- all change artifacts
- latest review and verify evidence
- release note or skip reason
- `traceability-matrix.md`

## Write

- accepted OpenSpec specs
- LLMWiki concepts/entities/traceability entries when available
- archive progress receipt

## Gate

- Latest review verdict is ready.
- Verify evidence is still bound to current disk facts.
- Release gate passed or skip reason is explicit.
- Traceability matrix covers completed tasks.
- Knowledge writeback is complete or deferred with reason.

Append a Codex gate receipt to `progress.md`.
