---
name: sdd-verify
description: Codex wrapper for the SDD/4D verify stage: collect reproducible evidence and confirm the 4D chain is proven.
license: MIT
compatibility: Codex, sdd-harness, trinity-verify
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-verify

Use `sdd-harness` first, then `trinity-verify`.

## Purpose

Verify that claims match disk facts, test output, probe evidence, and review status.

## Read

- `review-notes.md`
- `progress.md`
- captured test output
- probe/evidence audit reports when available
- `traceability-matrix.md`

## Write

- verification evidence summary in `progress.md`
- failure classification
- updated traceability evidence links

## Gate

- Tests and probes pass or have explicit waivers.
- Evidence audit inputs are bound to current disk state.
- Latest review verdict is ready before release/archive.
- Traceability gaps are closed or recorded as blocking.

Append a Codex gate receipt to `progress.md`.
