---
name: sdd-review
description: Codex wrapper for the SDD/4D review stage: review architecture, boundary discipline, implementation diff, and traceability.
license: MIT
compatibility: Codex, sdd-harness
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-review

Use `sdd-harness` first.

## Purpose

Review the change against DDD, SDD, BDD, TDD, and evidence obligations before verification.

## Read

- `domain-boundary.md`
- `specs/**/spec.md`
- `behavior-scenarios.md`
- `tasks.md`
- implementation diff
- `traceability-matrix.md`

## Write

- `.sdd/runs/<run>/review-notes.md`
- review learnings in `findings.md`
- `progress.md`

## Gate

- Verdict is `ready`, `needs-fix`, or `rejected`.
- Boundary and traceability findings are triaged.
- Line-level or deterministic review findings are fixed, waived, or recorded as risk.

Append a Codex gate receipt to `progress.md`.
