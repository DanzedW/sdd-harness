---
name: sdd-test
description: Codex wrapper for the SDD/4D test stage: turn requirements and BDD scenarios into a test matrix and durable test case definitions.
license: MIT
compatibility: Codex, sdd-harness
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-test

Use `sdd-harness` first.

## Purpose

Define how behavior will be verified. In 4D, this is the BDD-to-TDD bridge.

## Read

- `acceptance-criteria.md`
- `behavior-scenarios.md`
- `specs/**/spec.md`
- `design.md`

## Write

- `test-matrix.md` or `llmwiki/wiki/testing/matrices/test-matrix.md`
- `llmwiki/wiki/testing/cases/TC-*.md` when LLMWiki is available
- updates to `behavior-scenarios.md` with automation targets

## Gate

- Must requirements have behavior scenarios.
- Behavior scenarios have test targets.
- Coverage gaps are recorded.
- TDD can start with clear RED tests.

Append a Codex gate receipt to `progress.md`.
