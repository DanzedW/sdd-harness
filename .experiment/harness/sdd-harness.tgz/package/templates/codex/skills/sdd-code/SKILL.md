---
name: sdd-code
description: Codex wrapper for the SDD/4D code stage: implement with TDD through Trinity apply and keep traceability receipts current.
license: MIT
compatibility: Codex, sdd-harness, trinity-apply
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-code

Use `sdd-harness` first, then `trinity-apply`.

## Purpose

Implement one vertical slice at a time. In 4D, every RED test must trace to a BDD scenario and an OpenSpec requirement.

## Read

- `tasks.md`
- `design.md`
- `specs/**/spec.md`
- `behavior-scenarios.md`
- `findings.md`

## Write

- implementation diff
- unit/integration tests
- `progress.md`
- `traceability-matrix.md` rows for completed tasks

## Gate

- Task checkbox is updated only after implementation and tests pass.
- Test output is captured or a waiver is recorded.
- Every implemented task has a traceability row.
- Boundary violations are fixed or escalated before continuing.

Append a Codex gate receipt to `progress.md`.
