---
name: sdd-product
description: Codex wrapper for the SDD/4D product stage: create PRD, acceptance criteria, and BDD-ready functional test draft.
license: MIT
compatibility: Codex, sdd-harness
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-product

Use `sdd-harness` first.

## Purpose

Convert clarified intent into product artifacts. In 4D, this stage connects DDD ownership to SDD contract and prepares BDD scenarios.

## Read

- `findings.md`
- `domain-boundary.md` if present
- existing product knowledge and accepted specs

## Write

- `proposal.md`
- `acceptance-criteria.md`
- `functional-test-draft.yaml`
- `behavior-scenarios.md` for critical behavior

## Gate

- Proposal has user, problem, scope, non-goals, and metrics.
- Acceptance criteria are testable.
- Critical behavior has Given/When/Then scenarios or a tracked gap.
- DDD gate is satisfied or explicitly blocking.

Append a Codex gate receipt to `progress.md`.
