---
name: sdd-dev
description: Codex wrapper for the SDD/4D dev stage: produce OpenSpec specs, design, tasks, and boundary-aware engineering plan.
license: MIT
compatibility: Codex, sdd-harness, trinity-new, trinity-continue
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-dev

Use `sdd-harness` first, then Trinity skills for OpenSpec work.

## Purpose

Create the SDD contract: proposal, spec deltas, design, and tasks. In 4D, this stage must preserve DDD boundaries and expose BDD/TDD obligations.

## Read

- `proposal.md`
- `acceptance-criteria.md`
- `domain-boundary.md`
- `behavior-scenarios.md`
- existing specs and code graph when available

## Write

- `specs/**/spec.md`
- `design.md`
- `tasks.md`
- updates to `findings.md` and `progress.md`

## Gate

- OpenSpec deltas use ADDED/MODIFIED/REMOVED requirements.
- `design.md` contains File Structure Plan and boundary notes.
- `tasks.md` names test obligations and includes boundary notes.
- Each important task can trace to DDD and BDD artifacts.

Append a Codex gate receipt to `progress.md`.
