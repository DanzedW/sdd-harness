---
name: sdd-grill
description: Codex wrapper for the SDD/4D grill stage: clarify intent, define terms, route the change, and start DDD boundary discovery.
license: MIT
compatibility: Codex, sdd-harness
metadata:
  version: "0.2.0-4d"
  generatedBy: "sdd-harness"
---

# sdd-grill

Use `sdd-harness` first.

## Purpose

Clarify the change before product or spec work. In 4D, this stage starts DDD by identifying language, boundaries, risks, and ADR candidates.

## Read

- `AGENTS.md`, `README.md`, and project steering docs.
- Existing OpenSpec specs and active change files when present.
- LLMWiki or local wiki glossary when available.

## Write

- `openspec/changes/<change>/findings.md`
- `openspec/changes/<change>/brief.md`
- `openspec/changes/<change>/domain-boundary.md` when ownership or context is non-trivial.

## Gate

- Terms are defined.
- In-scope and out-of-scope boundaries are explicit.
- ADR candidates are listed.
- DDD uncertainty is either resolved or recorded as blocking.

Append a Codex gate receipt to `progress.md`.
