# Domain Boundary

> 4D layer: DDD.
> Gate: must be complete before the change is treated as ready for stable OpenSpec design.

## Domain

- Domain:
- Bounded context:
- Business fact owner:
- Adjacent contexts:

## Model

| Type | Name | Responsibility | Notes |
|---|---|---|---|
| Entity |  |  |  |
| Value object |  |  |  |
| Aggregate |  |  |  |
| Policy / service |  |  |  |

## Invariants

-

## Business Rules Versus Implementation Details

| Rule | Business rule or implementation detail | Owner | Evidence |
|---|---|---|---|
|  |  |  |  |

## Cross-Context Risk

- Does this change cross bounded contexts?
- If yes, what is the integration contract?
- If ownership is unclear, should the change split or create an ADR?

## DDD Gate Receipt

```yaml
domain_defined: false
owner_defined: false
invariants_defined: false
cross_context_risk_reviewed: false
adr_needed: false
```
