# Traceability Matrix

> 4D layer: Evidence.
> Gate: must be complete before archive.

| Chain ID | DDD boundary | OpenSpec requirement | BDD scenario | TDD test | Implementation diff | Verification evidence | LLMWiki entry |
|---|---|---|---|---|---|---|---|
| TRACE-001 |  |  |  |  |  |  |  |

## Missing Links

-

## Waivers

| Waiver ID | Missing link | Reason | Owner | Expiry |
|---|---|---|---|---|
|  |  |  |  |  |

## Traceability Gate Receipt

```yaml
all_completed_tasks_traced: false
all_must_scenarios_have_tests: false
all_tests_map_to_requirements: false
verification_evidence_bound_to_current_disk: false
archive_writeback_target_defined: false
```
